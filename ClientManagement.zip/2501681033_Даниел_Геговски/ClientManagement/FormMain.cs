﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ClientManagement
{
    public partial class FormMain : Form
    {
        System.ComponentModel.BindingList<Client> clients = new System.ComponentModel.BindingList<Client>();
        public FormMain()
        {
            InitializeComponent();
            lbClients.DataSource = clients;  
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            FormDetails form = new FormDetails();

            if (form.ShowDialog() == DialogResult.OK)
            {
                Client newClient = new Client();
                newClient.FirstName = form.txtFirstName.Text;
                newClient.LastName = form.txtLastName.Text;
                newClient.Gender = form.cmbGender.Text;
                newClient.EGN = form.txtEGN.Text;
                newClient.Address = form.txtAddress.Text;
                newClient.Phone = form.txtPhone.Text;
                newClient.Email = form.txtEmail.Text;

                clients.Add(newClient);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (lbClients.SelectedItem != null)
            {
                Client selectedClient = (Client)lbClients.SelectedItem;
                FormDetails form = new FormDetails();

                form.txtFirstName.Text = selectedClient.FirstName;
                form.txtLastName.Text = selectedClient.LastName;
                form.cmbGender.Text = selectedClient.Gender;
                form.txtEGN.Text = selectedClient.EGN;
                form.txtAddress.Text = selectedClient.Address;
                form.txtPhone.Text = selectedClient.Phone;
                form.txtEmail.Text = selectedClient.Email;

                if (form.ShowDialog() == DialogResult.OK)
                {
                    selectedClient.FirstName = form.txtFirstName.Text;
                    selectedClient.LastName = form.txtLastName.Text;
                    selectedClient.Gender = form.cmbGender.Text;
                    selectedClient.EGN = form.txtEGN.Text;
                    selectedClient.Address = form.txtAddress.Text;
                    selectedClient.Phone = form.txtPhone.Text;
                    selectedClient.Email = form.txtEmail.Text;

                    int index = lbClients.SelectedIndex;
                    clients.ResetItem(index);
                }
            }
            else
            {
                MessageBox.Show("Моля, първо изберете клиент от списъка!");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lbClients.SelectedItem != null)
            {
                Client toRemove = (Client)lbClients.SelectedItem;
                clients.Remove(toRemove);
            }
            else
            {
                MessageBox.Show("Моля, първо изберете клиент от списъка!");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter("clients.txt"))
            {
                foreach (Client c in clients)
                {
                    sw.WriteLine($"{c.FirstName};{c.LastName};{c.EGN};{c.Phone}");
                }
            }
            MessageBox.Show("Данните са запазени успешно!");
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            if (lbClients.SelectedItem != null)
            {
                Client c = (Client)lbClients.SelectedItem;
                string fullInfo = $"Име и Фамилия: {c.FirstName} {c.LastName}\n" +
                                  $"Пол: {c.Gender}\n" +
                                  $"ЕГН: {c.EGN}\n" +
                                  $"Адрес: {c.Address}\n" +
                                  $"Телефон: {c.Phone}\n" +
                                  $"Имейл: {c.Email}";

                MessageBox.Show(fullInfo, "Информация от базата данни");
            }
            else
            {
                MessageBox.Show("Моля, първо изберете клиент от списъка!");
            }
        }

        private void btnAvtorInfo_Click(object sender, EventArgs e)
        {
            string authorDetails = "ИНФОРМАЦИЯ ЗА АВТОРА:\n\n" +
                                   "Име: Даниел Геговски\n" +
                                   "Специалност: Софтуерни технологии и дизайн\n" +
                                   "Университет: Пловдивски университет\n" +
                                   "Курс: I-ви курс\n" +
                                   "Дисциплина: Създаване на ГПИ\n" +
                                   "Проект: Задача 4 - Мениджър на клиенти";

            MessageBox.Show(authorDetails, "Данни за разработчика", MessageBoxButtons.OK);
        }
    }
}
